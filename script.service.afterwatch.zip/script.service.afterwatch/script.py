# -*- coding: utf-8 -*-
if __name__ == "__main__":
    import xbmcaddon
    xbmcaddon.Addon().openSettings()
